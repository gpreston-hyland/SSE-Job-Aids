--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0 (Debian 17.0-1.pgdg120+1)
-- Dumped by pg_dump version 17.0 (Debian 17.0-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mydb;
--
-- Name: mydb; Type: DATABASE; Schema: -; Owner: app_mydb
--

CREATE DATABASE mydb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE mydb OWNER TO app_mydb;

\connect mydb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: gen_claim_number(date, text); Type: FUNCTION; Schema: public; Owner: app_mydb
--

CREATE FUNCTION public.gen_claim_number(claim_date date, lob_abbrev text) RETURNS text
    LANGUAGE sql
    AS $$ select concat(lob_abbrev,extract(year from claim_date),'-',nextval('claim_counter_seq')); $$;


ALTER FUNCTION public.gen_claim_number(claim_date date, lob_abbrev text) OWNER TO app_mydb;

--
-- Name: gen_policy_number(text); Type: FUNCTION; Schema: public; Owner: app_mydb
--

CREATE FUNCTION public.gen_policy_number(lob_abbrev text) RETURNS text
    LANGUAGE sql
    AS $$ select concat(lob_abbrev,'-',trim(to_char(nextval('policy_counter_seq'),'000000'))); $$;


ALTER FUNCTION public.gen_policy_number(lob_abbrev text) OWNER TO app_mydb;

--
-- Name: gen_producer_code(text); Type: FUNCTION; Schema: public; Owner: app_mydb
--

CREATE FUNCTION public.gen_producer_code(producer_type text) RETURNS text
    LANGUAGE sql
    AS $$ select concat(left(upper(producer_type),1),nextval('producers_counter_seq'));
 $$;


ALTER FUNCTION public.gen_producer_code(producer_type text) OWNER TO app_mydb;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: business; Type: TABLE; Schema: public; Owner: app_mydb
--

CREATE TABLE public.business (
    business_id integer NOT NULL,
    business_name character varying,
    business_uuid uuid,
    point_of_contact_id integer,
    website character varying,
    business_phone character varying,
    address character varying,
    city character varying,
    state character varying,
    zip character varying,
    tax_id_number character varying
);


ALTER TABLE public.business OWNER TO app_mydb;

--
-- Name: business_business_id_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.business_business_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.business_business_id_seq OWNER TO app_mydb;

--
-- Name: business_business_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_mydb
--

ALTER SEQUENCE public.business_business_id_seq OWNED BY public.business.business_id;


--
-- Name: claim; Type: TABLE; Schema: public; Owner: app_mydb
--

CREATE TABLE public.claim (
    claim_id integer NOT NULL,
    policy_id integer,
    claim_number character varying,
    claim_date date,
    claimant_first_name character varying,
    claimant_last_name character varying,
    claim_description text,
    claim_status character varying,
    claim_amount numeric,
    damage_location character varying,
    damage_description character varying,
    police_report_filed boolean DEFAULT false,
    insurance_adjuster_assigned boolean DEFAULT false,
    appraisal_date date,
    appraisal_amount numeric,
    repair_completion_date date,
    total_claim_paid numeric,
    additional_notes text,
    ecm_folder_id uuid
);


ALTER TABLE public.claim OWNER TO app_mydb;

--
-- Name: claim_claim_id_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.claim_claim_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.claim_claim_id_seq OWNER TO app_mydb;

--
-- Name: claim_claim_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_mydb
--

ALTER SEQUENCE public.claim_claim_id_seq OWNED BY public.claim.claim_id;


--
-- Name: claim_counter_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.claim_counter_seq
    AS integer
    START WITH 100000
    INCREMENT BY 1
    MINVALUE 100000
    MAXVALUE 999999
    CACHE 1
    CYCLE;


ALTER SEQUENCE public.claim_counter_seq OWNER TO app_mydb;

--
-- Name: line_of_business; Type: TABLE; Schema: public; Owner: app_mydb
--

CREATE TABLE public.line_of_business (
    lob_id integer NOT NULL,
    lob_type character varying,
    lob_abbrev character varying,
    lob_name character varying
);


ALTER TABLE public.line_of_business OWNER TO app_mydb;

--
-- Name: policy; Type: TABLE; Schema: public; Owner: app_mydb
--

CREATE TABLE public.policy (
    policy_id integer NOT NULL,
    policy_number character varying,
    policy_status character varying,
    policy_start_date date,
    policy_end_date date,
    coverage_limit numeric,
    premium_amount numeric,
    policy_vip boolean DEFAULT false,
    policy_lob_id integer,
    policy_producer_id integer,
    contacts_id integer,
    business_id integer,
    ecm_folder_id character varying,
    policy_holder_id integer
);


ALTER TABLE public.policy OWNER TO app_mydb;

--
-- Name: claim_full_view; Type: VIEW; Schema: public; Owner: app_mydb
--

CREATE VIEW public.claim_full_view AS
 SELECT c.claim_id,
    c.policy_id,
    c.claim_number,
    c.claim_date,
    c.claimant_first_name,
    c.claimant_last_name,
    c.claim_description,
    c.claim_status,
    c.claim_amount,
    c.damage_location,
    c.damage_description,
    c.police_report_filed,
    c.insurance_adjuster_assigned,
    c.appraisal_date,
    c.appraisal_amount,
    c.repair_completion_date,
    c.total_claim_paid,
    c.additional_notes,
    c.ecm_folder_id AS claim_ecm_folder_id,
    p.policy_number,
    p.policy_status,
    p.policy_start_date,
    p.policy_end_date,
    p.coverage_limit,
    p.ecm_folder_id AS policy_ecm_folder_id,
    p.policy_vip,
    lob.lob_type,
    lob.lob_abbrev,
    lob.lob_name
   FROM ((public.claim c
     JOIN public.policy p ON ((c.policy_id = p.policy_id)))
     JOIN public.line_of_business lob ON ((p.policy_lob_id = lob.lob_id)));


ALTER VIEW public.claim_full_view OWNER TO app_mydb;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: app_mydb
--

CREATE TABLE public.contacts (
    contacts_id integer NOT NULL,
    last_name character varying,
    first_name character varying,
    middle_init character varying,
    address character varying,
    city character varying,
    state character varying,
    zip character varying,
    contact_uuid uuid,
    dob date,
    ssn character varying,
    email character varying,
    phone_number character varying
);


ALTER TABLE public.contacts OWNER TO app_mydb;

--
-- Name: contacts_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.contacts_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contacts_contacts_id_seq OWNER TO app_mydb;

--
-- Name: contacts_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_mydb
--

ALTER SEQUENCE public.contacts_contacts_id_seq OWNED BY public.contacts.contacts_id;


--
-- Name: drivers; Type: TABLE; Schema: public; Owner: app_mydb
--

CREATE TABLE public.drivers (
    drivers_id integer NOT NULL,
    full_name character varying,
    dob date,
    license_number character varying,
    license_state character varying,
    years_employed integer,
    employment_status character varying
);


ALTER TABLE public.drivers OWNER TO app_mydb;

--
-- Name: drivers_drivers_id_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.drivers_drivers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.drivers_drivers_id_seq OWNER TO app_mydb;

--
-- Name: drivers_drivers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_mydb
--

ALTER SEQUENCE public.drivers_drivers_id_seq OWNED BY public.drivers.drivers_id;


--
-- Name: line_of_business_lob_id_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.line_of_business_lob_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.line_of_business_lob_id_seq OWNER TO app_mydb;

--
-- Name: line_of_business_lob_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_mydb
--

ALTER SEQUENCE public.line_of_business_lob_id_seq OWNED BY public.line_of_business.lob_id;


--
-- Name: producers; Type: TABLE; Schema: public; Owner: app_mydb
--

CREATE TABLE public.producers (
    producers_id integer NOT NULL,
    producer_type character varying,
    producer_code character varying,
    producer_name character varying,
    point_of_contact character varying,
    website character varying,
    phone_number character varying,
    address character varying,
    city character varying,
    state character varying,
    zip character varying
);


ALTER TABLE public.producers OWNER TO app_mydb;

--
-- Name: policy_business_full_view; Type: VIEW; Schema: public; Owner: app_mydb
--

CREATE VIEW public.policy_business_full_view AS
 SELECT p.policy_id,
    p.policy_number,
    p.policy_status,
    p.policy_start_date,
    p.policy_end_date,
    p.coverage_limit,
    p.premium_amount,
    p.policy_vip,
    p.policy_lob_id,
    lob.lob_type,
    lob.lob_abbrev,
    lob.lob_name,
    p.policy_holder_id,
    p.business_id,
    b.business_name,
    b.website AS business_website,
    b.business_phone,
    b.address AS business_address,
    b.city AS business_city,
    b.state AS business_state,
    b.zip AS business_zip,
    b.tax_id_number AS business_tax_id_number,
    p.contacts_id,
    c.last_name AS contact_last_name,
    c.first_name AS contact_first_name,
    c.middle_init AS contact_middle_init,
    c.address AS contact_address,
    c.city AS contact_city,
    c.state AS contact_state,
    c.zip AS contact_zip,
    c.dob AS contact_dob,
    c.ssn AS contact_ssn,
    c.email AS contact_email,
    p.policy_producer_id,
    p2.producer_code,
    p2.producer_type,
    p2.producer_name,
    p2.point_of_contact AS producer_point_of_contact,
    p2.website AS producer_website,
    p2.phone_number AS producer_phone_number,
    p2.address AS producer_address,
    p2.city AS producer_city,
    p2.state AS producer_state,
    p2.zip AS producer_zip,
    p.ecm_folder_id
   FROM ((((public.policy p
     JOIN public.line_of_business lob ON ((p.policy_lob_id = lob.lob_id)))
     JOIN public.producers p2 ON ((p.policy_producer_id = p2.producers_id)))
     JOIN public.contacts c ON ((c.contacts_id = p.contacts_id)))
     JOIN public.business b ON ((b.business_id = p.business_id)))
  WHERE ((lob.lob_abbrev)::text = 'CA'::text);


ALTER VIEW public.policy_business_full_view OWNER TO app_mydb;

--
-- Name: policy_counter_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.policy_counter_seq
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    MAXVALUE 999999
    CACHE 1
    CYCLE;


ALTER SEQUENCE public.policy_counter_seq OWNER TO app_mydb;

--
-- Name: policy_document; Type: TABLE; Schema: public; Owner: app_mydb
--

CREATE TABLE public.policy_document (
    policy_id integer NOT NULL,
    document_node_id uuid NOT NULL
);


ALTER TABLE public.policy_document OWNER TO app_mydb;

--
-- Name: policy_personal_full_view; Type: VIEW; Schema: public; Owner: app_mydb
--

CREATE VIEW public.policy_personal_full_view AS
 SELECT p.policy_id,
    p.policy_number,
    p.policy_status,
    p.policy_start_date,
    p.policy_end_date,
    p.coverage_limit,
    p.premium_amount,
    p.policy_vip,
    p.policy_lob_id,
    lob.lob_type,
    lob.lob_abbrev,
    lob.lob_name,
    p.policy_holder_id,
    ph.last_name AS policy_holder_last_name,
    ph.first_name AS policy_holder_first_name,
    ph.middle_init AS policy_holder_middle_init,
    ph.address AS policy_holder_address,
    ph.city AS policy_holder_city,
    ph.state AS policy_holder_state,
    ph.zip AS policy_holder_zip,
    ph.dob AS policy_holder_dob,
    ph.ssn AS policy_holder_ssn,
    ph.email AS policy_holder_email,
    p.contacts_id,
    c.last_name AS contact_last_name,
    c.first_name AS contact_first_name,
    c.middle_init AS contact_middle_init,
    c.address AS contact_address,
    c.city AS contact_city,
    c.state AS contact_state,
    c.zip AS contact_zip,
    c.dob AS contact_dob,
    c.ssn AS contact_ssn,
    c.email AS contact_email,
    p.ecm_folder_id,
    p.policy_producer_id,
    p2.producer_code,
    p2.producer_type,
    p2.producer_name,
    p2.point_of_contact AS producer_point_of_contact,
    p2.website AS producer_website,
    p2.phone_number AS producer_phone_number,
    p2.address AS producer_address,
    p2.city AS producer_city,
    p2.state AS producer_state,
    p2.zip AS producer_zip
   FROM ((((public.policy p
     JOIN public.line_of_business lob ON ((p.policy_lob_id = lob.lob_id)))
     JOIN public.producers p2 ON ((p.policy_producer_id = p2.producers_id)))
     JOIN public.contacts c ON ((c.contacts_id = p.contacts_id)))
     JOIN public.contacts ph ON ((ph.contacts_id = p.policy_holder_id)))
  WHERE ((lob.lob_abbrev)::text <> 'CA'::text);


ALTER VIEW public.policy_personal_full_view OWNER TO app_mydb;

--
-- Name: policy_policy_id_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.policy_policy_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.policy_policy_id_seq OWNER TO app_mydb;

--
-- Name: policy_policy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_mydb
--

ALTER SEQUENCE public.policy_policy_id_seq OWNED BY public.policy.policy_id;


--
-- Name: producers_counter_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.producers_counter_seq
    AS integer
    START WITH 10000
    INCREMENT BY 1
    MINVALUE 10000
    MAXVALUE 99999
    CACHE 1
    CYCLE;


ALTER SEQUENCE public.producers_counter_seq OWNER TO app_mydb;

--
-- Name: producers_producers_id_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.producers_producers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.producers_producers_id_seq OWNER TO app_mydb;

--
-- Name: producers_producers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_mydb
--

ALTER SEQUENCE public.producers_producers_id_seq OWNED BY public.producers.producers_id;


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: app_mydb
--

CREATE TABLE public.vehicles (
    vehicles_id integer NOT NULL,
    make character varying,
    model character varying,
    model_year integer,
    vin character varying,
    license_plate character varying,
    gross_vehicle_weight integer,
    ownership_status character varying
);


ALTER TABLE public.vehicles OWNER TO app_mydb;

--
-- Name: vehicles_vehicles_id_seq; Type: SEQUENCE; Schema: public; Owner: app_mydb
--

CREATE SEQUENCE public.vehicles_vehicles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicles_vehicles_id_seq OWNER TO app_mydb;

--
-- Name: vehicles_vehicles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_mydb
--

ALTER SEQUENCE public.vehicles_vehicles_id_seq OWNED BY public.vehicles.vehicles_id;


--
-- Name: business business_id; Type: DEFAULT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.business ALTER COLUMN business_id SET DEFAULT nextval('public.business_business_id_seq'::regclass);


--
-- Name: claim claim_id; Type: DEFAULT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.claim ALTER COLUMN claim_id SET DEFAULT nextval('public.claim_claim_id_seq'::regclass);


--
-- Name: contacts contacts_id; Type: DEFAULT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.contacts ALTER COLUMN contacts_id SET DEFAULT nextval('public.contacts_contacts_id_seq'::regclass);


--
-- Name: drivers drivers_id; Type: DEFAULT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.drivers ALTER COLUMN drivers_id SET DEFAULT nextval('public.drivers_drivers_id_seq'::regclass);


--
-- Name: line_of_business lob_id; Type: DEFAULT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.line_of_business ALTER COLUMN lob_id SET DEFAULT nextval('public.line_of_business_lob_id_seq'::regclass);


--
-- Name: policy policy_id; Type: DEFAULT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.policy ALTER COLUMN policy_id SET DEFAULT nextval('public.policy_policy_id_seq'::regclass);


--
-- Name: producers producers_id; Type: DEFAULT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.producers ALTER COLUMN producers_id SET DEFAULT nextval('public.producers_producers_id_seq'::regclass);


--
-- Name: vehicles vehicles_id; Type: DEFAULT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.vehicles ALTER COLUMN vehicles_id SET DEFAULT nextval('public.vehicles_vehicles_id_seq'::regclass);


--
-- Data for Name: business; Type: TABLE DATA; Schema: public; Owner: app_mydb
--

COPY public.business (business_id, business_name, business_uuid, point_of_contact_id, website, business_phone, address, city, state, zip, tax_id_number) FROM stdin;
\.
COPY public.business (business_id, business_name, business_uuid, point_of_contact_id, website, business_phone, address, city, state, zip, tax_id_number) FROM '$$PATH$$/3465.dat';

--
-- Data for Name: claim; Type: TABLE DATA; Schema: public; Owner: app_mydb
--

COPY public.claim (claim_id, policy_id, claim_number, claim_date, claimant_first_name, claimant_last_name, claim_description, claim_status, claim_amount, damage_location, damage_description, police_report_filed, insurance_adjuster_assigned, appraisal_date, appraisal_amount, repair_completion_date, total_claim_paid, additional_notes, ecm_folder_id) FROM stdin;
\.
COPY public.claim (claim_id, policy_id, claim_number, claim_date, claimant_first_name, claimant_last_name, claim_description, claim_status, claim_amount, damage_location, damage_description, police_report_filed, insurance_adjuster_assigned, appraisal_date, appraisal_amount, repair_completion_date, total_claim_paid, additional_notes, ecm_folder_id) FROM '$$PATH$$/3469.dat';

--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: app_mydb
--

COPY public.contacts (contacts_id, last_name, first_name, middle_init, address, city, state, zip, contact_uuid, dob, ssn, email, phone_number) FROM stdin;
\.
COPY public.contacts (contacts_id, last_name, first_name, middle_init, address, city, state, zip, contact_uuid, dob, ssn, email, phone_number) FROM '$$PATH$$/3461.dat';

--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: app_mydb
--

COPY public.drivers (drivers_id, full_name, dob, license_number, license_state, years_employed, employment_status) FROM stdin;
\.
COPY public.drivers (drivers_id, full_name, dob, license_number, license_state, years_employed, employment_status) FROM '$$PATH$$/3457.dat';

--
-- Data for Name: line_of_business; Type: TABLE DATA; Schema: public; Owner: app_mydb
--

COPY public.line_of_business (lob_id, lob_type, lob_abbrev, lob_name) FROM stdin;
\.
COPY public.line_of_business (lob_id, lob_type, lob_abbrev, lob_name) FROM '$$PATH$$/3455.dat';

--
-- Data for Name: policy; Type: TABLE DATA; Schema: public; Owner: app_mydb
--

COPY public.policy (policy_id, policy_number, policy_status, policy_start_date, policy_end_date, coverage_limit, premium_amount, policy_vip, policy_lob_id, policy_producer_id, contacts_id, business_id, ecm_folder_id, policy_holder_id) FROM stdin;
\.
COPY public.policy (policy_id, policy_number, policy_status, policy_start_date, policy_end_date, coverage_limit, premium_amount, policy_vip, policy_lob_id, policy_producer_id, contacts_id, business_id, ecm_folder_id, policy_holder_id) FROM '$$PATH$$/3467.dat';

--
-- Data for Name: policy_document; Type: TABLE DATA; Schema: public; Owner: app_mydb
--

COPY public.policy_document (policy_id, document_node_id) FROM stdin;
\.
COPY public.policy_document (policy_id, document_node_id) FROM '$$PATH$$/3470.dat';

--
-- Data for Name: producers; Type: TABLE DATA; Schema: public; Owner: app_mydb
--

COPY public.producers (producers_id, producer_type, producer_code, producer_name, point_of_contact, website, phone_number, address, city, state, zip) FROM stdin;
\.
COPY public.producers (producers_id, producer_type, producer_code, producer_name, point_of_contact, website, phone_number, address, city, state, zip) FROM '$$PATH$$/3463.dat';

--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: app_mydb
--

COPY public.vehicles (vehicles_id, make, model, model_year, vin, license_plate, gross_vehicle_weight, ownership_status) FROM stdin;
\.
COPY public.vehicles (vehicles_id, make, model, model_year, vin, license_plate, gross_vehicle_weight, ownership_status) FROM '$$PATH$$/3459.dat';

--
-- Name: business_business_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.business_business_id_seq', 500, true);


--
-- Name: claim_claim_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.claim_claim_id_seq', 10, true);


--
-- Name: claim_counter_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.claim_counter_seq', 100009, false);


--
-- Name: contacts_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.contacts_contacts_id_seq', 1000, true);


--
-- Name: drivers_drivers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.drivers_drivers_id_seq', 500, true);


--
-- Name: line_of_business_lob_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.line_of_business_lob_id_seq', 8, true);


--
-- Name: policy_counter_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.policy_counter_seq', 3168, true);


--
-- Name: policy_policy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.policy_policy_id_seq', 500, true);


--
-- Name: producers_counter_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.producers_counter_seq', 10302, true);


--
-- Name: producers_producers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.producers_producers_id_seq', 500, true);


--
-- Name: vehicles_vehicles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_mydb
--

SELECT pg_catalog.setval('public.vehicles_vehicles_id_seq', 1000, true);


--
-- Name: business business_pk; Type: CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.business
    ADD CONSTRAINT business_pk PRIMARY KEY (business_id);


--
-- Name: claim claim_pk; Type: CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.claim
    ADD CONSTRAINT claim_pk PRIMARY KEY (claim_id);


--
-- Name: contacts contacts_pk; Type: CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pk PRIMARY KEY (contacts_id);


--
-- Name: drivers drivers_pk; Type: CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pk PRIMARY KEY (drivers_id);


--
-- Name: line_of_business lob_pk; Type: CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.line_of_business
    ADD CONSTRAINT lob_pk PRIMARY KEY (lob_id);


--
-- Name: policy_document policy_document_pk; Type: CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.policy_document
    ADD CONSTRAINT policy_document_pk PRIMARY KEY (policy_id, document_node_id);


--
-- Name: policy policy_pk; Type: CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.policy
    ADD CONSTRAINT policy_pk PRIMARY KEY (policy_id);


--
-- Name: producers producers_pk; Type: CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.producers
    ADD CONSTRAINT producers_pk PRIMARY KEY (producers_id);


--
-- Name: vehicles vehicles_pk; Type: CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pk PRIMARY KEY (vehicles_id);


--
-- Name: business business_contacts_fk; Type: FK CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.business
    ADD CONSTRAINT business_contacts_fk FOREIGN KEY (point_of_contact_id) REFERENCES public.contacts(contacts_id);


--
-- Name: claim claim_policy_fk; Type: FK CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.claim
    ADD CONSTRAINT claim_policy_fk FOREIGN KEY (policy_id) REFERENCES public.policy(policy_id);


--
-- Name: policy policy_business_fk; Type: FK CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.policy
    ADD CONSTRAINT policy_business_fk FOREIGN KEY (business_id) REFERENCES public.business(business_id);


--
-- Name: policy policy_contacts_fk; Type: FK CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.policy
    ADD CONSTRAINT policy_contacts_fk FOREIGN KEY (contacts_id) REFERENCES public.contacts(contacts_id);


--
-- Name: policy_document policy_document_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.policy_document
    ADD CONSTRAINT policy_document_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policy(policy_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: policy policy_line_of_business_fk; Type: FK CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.policy
    ADD CONSTRAINT policy_line_of_business_fk FOREIGN KEY (policy_lob_id) REFERENCES public.line_of_business(lob_id);


--
-- Name: policy policy_producers_fk; Type: FK CONSTRAINT; Schema: public; Owner: app_mydb
--

ALTER TABLE ONLY public.policy
    ADD CONSTRAINT policy_producers_fk FOREIGN KEY (policy_producer_id) REFERENCES public.producers(producers_id);


--
-- PostgreSQL database dump complete
--

